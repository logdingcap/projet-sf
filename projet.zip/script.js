// script.js (Mise à jour complète)

if (!localStorage.getItem('invoices')) {
    const initialInvoices = [
        {
            id: "2026_03_FACTURE_DUPONT_J",
            formateur: "Jean Dupont",
            matiere: "Economie-Droit",
            date: "2026-03-12",
            heures: 4,
            taux: 45,
            statut: "Prêt pour validation",
            netYpareoConforme: true
        },
        {
            id: "2026_03_FACTURE_MARTIN_S",
            formateur: "Sophie Martin",
            matiere: "Communication",
            date: "2026-03-15",
            heures: 7,
            taux: 45,
            statut: "En attente d'émargement",
            netYpareoConforme: false
        }
    ];
    localStorage.setItem('invoices', JSON.stringify(initialInvoices));
}

function getInvoices() {
    return JSON.parse(localStorage.getItem('invoices'));
}

function saveInvoices(invoices) {
    localStorage.setItem('invoices', JSON.stringify(invoices));
}

// ---- NOUVELLES FONCTIONS POUR LES LIGNES MULTIPLES ----
function ajouterLigne() {
    const container = document.getElementById('lignes-facture');
    const row = document.createElement('div');
    row.className = 'ligne-cours form-group-row';
    row.innerHTML = `
        <input type="date" class="date-cours" required>
        <input type="number" class="heures-cours" placeholder="Nb d'heures" min="1" required>
        <button type="button" class="btn-danger" onclick="supprimerLigne(this)">X</button>
    `;
    container.appendChild(row);
}

function supprimerLigne(button) {
    const row = button.parentElement;
    const allRows = document.querySelectorAll('.ligne-cours');
    if (allRows.length > 1) {
        row.remove();
    } else {
        alert("Vous devez conserver au moins une ligne pour la facture.");
    }
}
// -------------------------------------------------------

function submitInvoice(e) {
    e.preventDefault();
    const matiere = document.getElementById('matiere').value;
    const taux = document.getElementById('taux').value;
    
    // Récupération de toutes les lignes de cours
    const lignes = document.querySelectorAll('.ligne-cours');
    let totalHeures = 0;
    let detailsCours = [];
    
    lignes.forEach(ligne => {
        const date = ligne.querySelector('.date-cours').value;
        const heures = parseInt(ligne.querySelector('.heures-cours').value);
        totalHeures += heures;
        detailsCours.push({ date: date, heures: heures });
    });

    let invoices = getInvoices();

    const newInvoice = {
        id: `2026_04_FACTURE_USER_${Math.floor(Math.random()*1000)}`,
        formateur: "Utilisateur Courant",
        matiere: matiere,
        date: detailsCours[0].date, // On garde la première date comme repère visuel court
        details: detailsCours,      // On sauvegarde tout le détail
        heures: totalHeures,
        taux: parseInt(taux),
        statut: "Prêt pour validation", 
        netYpareoConforme: true
    };

    invoices.push(newInvoice);
    saveInvoices(invoices);

    alert(`Facture générée avec succès ! Total : ${totalHeures} heures.\nSignature numérique apposée.\nVérification NetYparéo : Émargements confirmés.`);
    
    // Réinitialisation du formulaire
    e.target.reset();
    document.getElementById('lignes-facture').innerHTML = `
        <label style="font-weight: bold; display: block; margin-bottom: 10px;">Détail des cours :</label>
        <div class="ligne-cours form-group-row">
            <input type="date" class="date-cours" required>
            <input type="number" class="heures-cours" placeholder="Nb d'heures" min="1" required>
            <button type="button" class="btn-danger" onclick="supprimerLigne(this)">X</button>
        </div>
    `;
    
    renderTables();
}

function verifyNetYpareo(id) {
    let invoices = getInvoices();
    const invoice = invoices.find(inv => inv.id === id);
    if(invoice && invoice.statut === "En attente d'émargement") {
        alert("Interrogation de l'API NetYparéo...\nÉmargement désormais validé par le formateur sur l'ERP.");
        invoice.statut = "Prêt pour validation";
        invoice.netYpareoConforme = true;
        saveInvoices(invoices);
        renderTables();
    }
}

function signAndValidate(id) {
    let invoices = getInvoices();
    const invoice = invoices.find(inv => inv.id === id);
    if(invoice && invoice.netYpareoConforme) {
        invoice.statut = "Validé / En compta";
        alert("Visa numérique Admin apposé.\nLe PDF est verrouillé et transféré automatiquement au service Comptabilité.");
        saveInvoices(invoices);
        renderTables();
    }
}

function markAsPaid(id) {
    let invoices = getInvoices();
    const invoice = invoices.find(inv => inv.id === id);
    if(invoice) {
        invoice.statut = "Payé";
        alert("Virement déclenché. Un email de notification automatique a été envoyé au formateur.");
        saveInvoices(invoices);
        renderTables();
    }
}

function getBadgeClass(statut) {
    switch(statut) {
        case "Brouillon": return "badge-draft";
        case "En attente d'émargement": return "badge-warning";
        case "Prêt pour validation": return "badge-ready";
        case "Validé / En compta": return "badge-valid";
        case "Payé": return "badge-valid";
        default: return "";
    }
}

function renderTables() {
    const invoices = getInvoices();

    const tbodyFormateur = document.getElementById('tbody-formateur');
    if (tbodyFormateur) {
        tbodyFormateur.innerHTML = invoices.map(inv => `
            <tr>
                <td>${inv.id}</td>
                <td>${inv.matiere}</td>
                <td>${inv.heures} h</td>
                <td>${inv.heures * inv.taux} €</td>
                <td><span class="badge ${getBadgeClass(inv.statut)}">${inv.statut}</span></td>
                <td>${inv.netYpareoConforme ? '✅ Conforme' : '❌ Non émargé'}</td>
            </tr>
        `).join('');
    }

    const tbodyAdmin = document.getElementById('tbody-admin');
    if (tbodyAdmin) {
        tbodyAdmin.innerHTML = invoices.filter(inv => inv.statut !== "Payé").map(inv => `
            <tr>
                <td>${inv.formateur}</td>
                <td>${inv.matiere}</td>
                <td>${inv.heures * inv.taux} €</td>
                <td><span class="badge ${getBadgeClass(inv.statut)}">${inv.statut}</span></td>
                <td>
                    ${inv.statut === "En attente d'émargement" ? 
                        `<button class="btn-warning btn-small" onclick="verifyNetYpareo('${inv.id}')">Revérifier NetYparéo</button>` : 
                        ''}
                    ${inv.statut === "Prêt pour validation" ? 
                        `<button class="btn-success btn-small" onclick="signAndValidate('${inv.id}')">Apposer Visa & Envoyer Compta</button>` : 
                        (inv.statut === "Validé / En compta" ? "Transmis à la compta" : "")}
                </td>
            </tr>
        `).join('');
    }

    const tbodyCompta = document.getElementById('tbody-compta');
    if (tbodyCompta) {
        tbodyCompta.innerHTML = invoices.filter(inv => inv.statut === "Validé / En compta" || inv.statut === "Payé").map(inv => `
            <tr>
                <td>📄 ${inv.id}.pdf (Certifié)</td>
                <td>${inv.formateur}</td>
                <td>${inv.heures * inv.taux} €</td>
                <td>Fin de mois (cycle UFA)</td>
                <td>
                    ${inv.statut === "Validé / En compta" ? 
                        `<button class="btn-success btn-small" onclick="markAsPaid('${inv.id}')">Marquer comme Payé (Virement fait)</button>` : 
                        "✅ Virement effectué"}
                </td>
            </tr>
        `).join('');
    }
}

window.onload = renderTables;